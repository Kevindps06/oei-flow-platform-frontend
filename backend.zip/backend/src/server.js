const path = require("path");
const express = require("express");
const cors = require("cors");

var app = express();

app.set("port", process.env.PORT || 80);

app.set("views", path.join(__dirname, "../dist"));

app.use(
  cors({
    origin: "*",
  })
);

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

app.use(express.static(app.get("views")));

app.get("/*", (req, res) => {
  res.setHeader("X-UA-Compatible", "IE=Edge");
  res.status(200).sendFile(path.join(app.get("views"), "index.html"));
});

app.listen(app.get("port"), () => {
  console.log(`Server running at port ${app.get("port")}...`);
});